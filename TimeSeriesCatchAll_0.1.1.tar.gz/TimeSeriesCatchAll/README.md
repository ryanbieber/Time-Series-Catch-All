## Looks at time series in IBM finance

## Installation
First, install `rtools` from [CRAN](https://cran.r-project.org/bin/windows/Rtools/)

Then, from inside `R` run:

``` r
install_local("TimeSeriesCatchAll_0.1.0.tar.gz", repos = NULL, type="source", dependencies = TRUE)
```
