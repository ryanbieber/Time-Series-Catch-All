## Looks at time series in IBM finance
